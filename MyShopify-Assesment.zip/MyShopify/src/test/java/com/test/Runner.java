package com.test;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.base.BaseClass;
import com.pom.PageObjectManager;

public class Runner extends BaseClass {

	PageObjectManager pom  = new PageObjectManager();
	String expected= "Copy of 14k Solid Bloom Earrings -- Arjun";
	
	@Test
	private void searchProduct() throws InterruptedException {
		launchBrowser("chrome");
		launchUrl("https://adnabu-arjun.myshopify.com/");
		clickButton(pom.getHom().getSearchbutton());
		passInput(pom.getHom().getInputSearch(), "Bloom Earrings");
		
		//	System.out.println(driver.getTitle());
			}
	@Test(dependsOnMethods = "searchProduct")
	private void selectProduct() {
		clickButton(pom.getHom().getButton());
		listData(pom.getHom().getAllProduct(), expected);
	}
	
	@Test(dependsOnMethods = "selectProduct")
	private void addtoBag() {
		clickButton(pom.getHom().getaddCart());
		sleep(5000);
		clickButton(pom.getHom().getViewCart());
		sleep(5000);
		

	}


	@Test(dependsOnMethods = "addtoBag")
	private void removeBagCart() {
		clickButton(pom.getHom().getRemoveCart());
		sleep(1000);
		clickButton(pom.getHom().getVerifyCart());
		String expected="Your cart is empty";
		String actual = getTex(pom.getHom().getValidation());
		Assert.assertEquals(actual,expected );

	}
	@AfterSuite
	private void terminateExecution() {
		terminateBrowser();
	}
}
