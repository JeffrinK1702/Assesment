package com.pom;

import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;

public class PageObjectManager extends BaseClass {

	public PageObjectManager() {
		PageFactory.initElements(driver, this);
	}
	
	HomePage hom;
	
	public HomePage getHom() {
		hom=new HomePage();
		return hom;
	}
}
