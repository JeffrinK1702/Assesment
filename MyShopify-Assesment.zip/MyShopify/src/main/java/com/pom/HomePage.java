package com.pom;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;

public class HomePage extends BaseClass {

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//span//following-sibling::*[@class=\"modal__toggle-open icon icon-search\"])[1]")
	private WebElement searchbutton;

	@FindBy(name = "q")
	private WebElement inputSearch;

	@FindBy(xpath = "(//button[@class='search__button field__button'])[1]")
	private WebElement button;


	@FindBy(xpath = "//li[@class='grid__item scroll-trigger animate--slide-in']")
	private List<WebElement> allProduct;

	@FindBy(xpath = "//button[@name='add']")
	private WebElement addCart;

	@FindBy(xpath = "//h1[text()='Your cart is empty']")
	private WebElement validation;

	@FindBy(xpath = "(//a[@href='/cart'])[1]")
	private WebElement viewCart;
	
	@FindBy(xpath = "//a[@href='/cart/change?id=40875347509345:9e9e6b08fb50a6a7595ec36510f2e57c&quantity=0']")
	private WebElement removeCart;
	
	@FindBy(xpath = "(//a[@href='/cart'])[1]")
	private WebElement verifyCart;

	public WebElement getValidation() {
		return validation;
	}
	public WebElement getVerifyCart() {
		return verifyCart;
	}
	public WebElement getRemoveCart() {
		return removeCart;
	}
	public WebElement getViewCart() {
		return viewCart;
	}

	public WebElement getaddCart() {
		return addCart;
	}

	public List<WebElement> getAllProduct() {
		return allProduct;
	}
	public WebElement getButton() {
		return button;
	}
	public WebElement getSearchbutton() {
		return searchbutton;
	}
	public WebElement getInputSearch() {
		return inputSearch;
	}

}
